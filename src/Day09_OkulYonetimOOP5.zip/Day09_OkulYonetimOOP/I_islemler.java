package Day09_OkulYonetimOOP;

public interface I_islemler {
    /*
     ============= İŞLEMLER =============
            1-EKLEME
         2-ARAMA
         3-LİSTELEME
         4-SİLME
         5-ANA MENÜ
    Q-ÇIKIŞ
    */
     void ekleme ();
     void arama();
     void listeleme ();
     void silme ();
     void cikis ();



     static void method (){

      // bu methodu nasil override ederim ?
      // I_slem. method ?

     }

}
