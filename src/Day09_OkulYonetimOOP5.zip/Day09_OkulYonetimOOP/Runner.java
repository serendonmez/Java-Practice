package Day09_OkulYonetimOOP;

public class Runner {

    public static void main(String[] args) {
        AnaMenu anaMenu= new AnaMenu();
        anaMenu.menu();
    }
}
