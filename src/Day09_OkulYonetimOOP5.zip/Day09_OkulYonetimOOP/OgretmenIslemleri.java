package Day09_OkulYonetimOOP;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class OgretmenIslemleri implements I_islemler{

    /*
    Seçilen Kişi türüne göre aşağıdaki işlemleri gösteren bir alt menü daha gösterilsin.
    ============= İŞLEMLER =============
         1-EKLEME
         2-ARAMA
         3-LİSTELEME
         4-SİLME
         5-ANA MENÜ
         Q-ÇIKIŞ

    SEÇİMİNİZ:
     */

    Scanner scanner = new Scanner(System.in);

    List <Ogretmen> ogrentmenList= new ArrayList<>();

    int ogretmenSicilNo=230;


    void OgretmenIslemleri() {

        System.out.println(" ============Islemler ==============\n\t1-Ekleme  \n\t2-Arama\n\t3-Listeleme" +
                "\n\t4-Silme \n\t5-Anamenu \n\tQ-Cikis \n\n\nSeciminiz : ");

        char secim= scanner.nextLine().toUpperCase().charAt(0);
      switch (secim ){

          case '1': ekleme(); break;
          case '2':arama(); break;
          case '3': listeleme(); break;
          case '4': silme();break;
          case 'Q': cikis();break;
          default:System.out.println(" lütfen gecerli bir secim yapiniz");
      }

    }

    @Override
    public void ekleme() {

        System.out.println(" eklemek istediginiz ogrentmen sicil no yu giriniz ");

    }

    @Override
    public void arama() {

    }

    @Override
    public void listeleme() {

    }

    @Override
    public void silme() {

    }


    @Override
    public void cikis() {
        System.exit(0);

    }
}
